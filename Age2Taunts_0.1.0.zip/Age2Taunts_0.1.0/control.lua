-- script.on_event(defines.events.on_console_chat, function(event)
--     if event.message == '11' then
--         game.play_sound{path = "Herb_laugh", volume_modifier = 1}
--     end
-- end)


-- script.on_event(defines.events.on_console_chat, function(event)
--     if event.message <= '0' and >= '43' then
--         game.play_sound{path = event.message, volume_modifier = 1}
--     else
--         event.message == 'monkey' then
--             game.play_sound{path = 'monkey', volume_modifier = 1}
--         else
--             game.print("event.message")
--     end 
-- end)

script.on_event(defines.events.on_console_chat, function(event)
    if  event.message == '1' then
        game.play_sound{path = "1", volume_modifier = 1}
        elseif
        event.message == '2' then
        game.play_sound{path = "2", volume_modifier = 1}
        elseif
        event.message == '3' then
        game.play_sound{path = "3", volume_modifier = 1}
        elseif
        event.message == '4' then
        game.play_sound{path = "4", volume_modifier = 1}
        elseif
        event.message == '5' then
        game.play_sound{path = "5", volume_modifier = 1}
        elseif
        event.message == '6' then
        game.play_sound{path = "6", volume_modifier = 1}
        elseif
        event.message == '7' then
        game.play_sound{path = "7", volume_modifier = 1}
        elseif
        event.message == '8' then
        game.play_sound{path = "8", volume_modifier = 1}
        elseif
        event.message == '9' then
        game.play_sound{path = "9", volume_modifier = 1}
        elseif
        event.message == '10' then
        game.play_sound{path = "10", volume_modifier = 1}
        elseif
        event.message == '11' then
        game.play_sound{path = "11", volume_modifier = 1}
        elseif
        event.message == '12' then
        game.play_sound{path = "12", volume_modifier = 1}
        elseif
        event.message == '13' then
        game.play_sound{path = "13", volume_modifier = 1}
        elseif
        event.message == '14' then
        game.play_sound{path = "14", volume_modifier = 1}
        elseif
        event.message == '15' then
        game.play_sound{path = "15", volume_modifier = 1}
        elseif
        event.message == '16' then
        game.play_sound{path = "16", volume_modifier = 1}
        elseif
        event.message == '17' then
        game.play_sound{path = "17", volume_modifier = 1}
        elseif
        event.message == '18' then
        game.play_sound{path = "18", volume_modifier = 1}
        elseif
        event.message == '19' then
        game.play_sound{path = "19", volume_modifier = 1}
        elseif
        event.message == '20' then
        game.play_sound{path = "20", volume_modifier = 1}
        elseif
        event.message == '21' then
        game.play_sound{path = "21", volume_modifier = 1}
        elseif
        event.message == '22' then
        game.play_sound{path = "22", volume_modifier = 1}
        elseif
        event.message == '23' then
        game.play_sound{path = "23", volume_modifier = 1}
        elseif
        event.message == '24' then
        game.play_sound{path = "24", volume_modifier = 1}
        elseif
        event.message == '25' then
        game.play_sound{path = "25", volume_modifier = 1}
        elseif
        event.message == '26' then
        game.play_sound{path = "26", volume_modifier = 1}
        elseif
        event.message == '27' then
        game.play_sound{path = "27", volume_modifier = 1}
        elseif
        event.message == '28' then
        game.play_sound{path = "28", volume_modifier = 1}
        elseif
        event.message == '29' then
        game.play_sound{path = "29", volume_modifier = 1}
        elseif
        event.message == '30' then
        game.play_sound{path = "30", volume_modifier = 1}
        elseif
        event.message == '31' then
        game.play_sound{path = "31", volume_modifier = 1}
        elseif
        event.message == '32' then
        game.play_sound{path = "32", volume_modifier = 1}
        elseif
        event.message == '33' then
        game.play_sound{path = "33", volume_modifier = 1}
        elseif
        event.message == '34' then
        game.play_sound{path = "34", volume_modifier = 1}
        elseif
        event.message == '35' then
        game.play_sound{path = "35", volume_modifier = 1}
        elseif
        event.message == '36' then
        game.play_sound{path = "36", volume_modifier = 1}
        elseif
        event.message == '37' then
        game.play_sound{path = "37", volume_modifier = 1}
        elseif
        event.message == '38' then
        game.play_sound{path = "38", volume_modifier = 1}
        elseif
        event.message == '39' then
        game.play_sound{path = "39", volume_modifier = 1}
        elseif
        event.message == '40' then
        game.play_sound{path = "40", volume_modifier = 1}
        elseif
        event.message == '41' then
        game.play_sound{path = "41", volume_modifier = 1}
        elseif
        event.message == '42' then
        game.play_sound{path = "42", volume_modifier = 1}
        elseif
        event.message == '43' then
        game.play_sound{path = "43", volume_modifier = 1}
        elseif
        event.message == 'monkey' then
        game.play_sound{path = "monkey", volume_modifier = 1}
    end
end)


-- script.on_event(defines.events.on_console_chat, function(event)
--     if event.message == 'monkey' then
--         game.play_sound{path = "monkey", volume_modifier = 1}
--     end
-- end)


-- chat = {defines.events.on_console_chat}
-- local filters = {{filter="type", type="messege", messege="11"}}

-- script.on_event(chat, taunttoplay)

-- local chat script.on_event(defines.events.on_console_chat, eleven)



-- on_console_chat(message == "11")
local function eleven()
    game.play_sound{path = "Herb_laugh", volume_modifier = 1}
end
commands.add_command("11", nil, eleven)

